// بوابة اشتراكات بسيطة بدون أي مكتبات خارجية (Node 18+)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data.json');
const PUB = path.join(__dirname, 'public');

// كلمة سر الأدمن: من المتغير ADMIN_PASSWORD، وإلا تتولد عشوائياً وتنطبع مرة عند التشغيل
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
if (!process.env.ADMIN_PASSWORD) console.log('Admin password (set ADMIN_PASSWORD to change):', ADMIN_PASSWORD);

const defaults = { brand: 'اسم موقعك', announcement: '', default_sub_url: '', keys: [], nodes: [] };
let db = defaults;
try { db = { ...defaults, ...JSON.parse(fs.readFileSync(DATA, 'utf8')) }; } catch {}
const save = () => fs.writeFileSync(DATA, JSON.stringify(db, null, 2));

const sessions = new Map();           // token -> expiry
const attempts = new Map();           // ip -> {n, until}
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise(r => { let s = ''; req.on('data', c => { s += c; if (s.length > 1e5) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(s || '{}')); } catch { r({}); } }); });

function throttled(ip) {
  const a = attempts.get(ip);
  return a && a.n >= 8 && Date.now() < a.until;
}
function fail(ip) {
  const a = attempts.get(ip) || { n: 0 };
  a.n++; a.until = Date.now() + 10 * 60 * 1000; attempts.set(ip, a);
}
function isAdmin(req) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  const exp = sessions.get(t);
  return exp && exp > Date.now();
}
function status(k) {
  if (k.revoked) return 'revoked';
  if (k.expires_at && Date.now() > k.expires_at) return 'expired';
  return k.expires_at ? 'active' : 'unused';
}
function newKey(prefix) {
  const part = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `${prefix}-${part()}-${part()}-${part()}`;
}

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon' };

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const ip = req.socket.remoteAddress;

  // ---------- واجهة العميل ----------
  if (url.pathname === '/api/login' && req.method === 'POST') {
    if (throttled(ip)) return json(res, 429, { error: 'محاولات كثيرة، جرّب بعد قليل' });
    const { key } = await body(req);
    const k = db.keys.find(x => x.key === String(key || '').trim().toUpperCase());
    if (!k || k.revoked) { fail(ip); return json(res, 401, { error: 'مفتاح غير صالح' }); }
    if (!k.expires_at) { k.expires_at = Date.now() + k.days * 86400000; k.activated_at = Date.now(); save(); } // يبدأ العدّ عند أول دخول
    if (status(k) === 'expired') return json(res, 403, { error: 'انتهت صلاحية المفتاح' });
    return json(res, 200, {
      brand: db.brand, announcement: db.announcement,
      expires_at: k.expires_at,
      sub_url: k.sub_url || db.default_sub_url || '',
      nodes: db.nodes
    });
  }
  if (url.pathname === '/api/public' && req.method === 'GET') return json(res, 200, { brand: db.brand });

  // ---------- واجهة الأدمن ----------
  if (url.pathname === '/api/admin/login' && req.method === 'POST') {
    if (throttled(ip)) return json(res, 429, { error: 'محاولات كثيرة' });
    const { password = '' } = await body(req);
    const a = Buffer.from(String(password)), b = Buffer.from(ADMIN_PASSWORD);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) { fail(ip); return json(res, 401, { error: 'كلمة السر خاطئة' }); }
    const t = crypto.randomBytes(24).toString('hex');
    sessions.set(t, Date.now() + 8 * 3600000);
    return json(res, 200, { token: t });
  }
  if (url.pathname.startsWith('/api/admin/')) {
    if (!isAdmin(req)) return json(res, 401, { error: 'غير مصرّح' });
    const p = url.pathname.slice(11), b = req.method === 'POST' ? await body(req) : {};
    if (p === 'state') return json(res, 200, { ...db, keys: db.keys.map(k => ({ ...k, status: status(k) })) });
    if (p === 'keys/create') {
      const n = Math.min(Math.max(+b.count || 1, 1), 200), days = Math.max(+b.days || 30, 1);
      const prefix = String(b.prefix || 'KEY').replace(/[^A-Za-z0-9]/g, '').slice(0, 8).toUpperCase() || 'KEY';
      const made = Array.from({ length: n }, () => ({ key: newKey(prefix), days, expires_at: null, revoked: false, sub_url: String(b.sub_url || ''), note: String(b.note || ''), created_at: Date.now() }));
      db.keys.unshift(...made); save(); return json(res, 200, { keys: made.map(k => k.key) });
    }
    if (p === 'keys/revoke') { const k = db.keys.find(x => x.key === b.key); if (k) { k.revoked = !k.revoked; save(); } return json(res, 200, {}); }
    if (p === 'keys/delete') { db.keys = db.keys.filter(x => x.key !== b.key); save(); return json(res, 200, {}); }
    if (p === 'settings') {
      for (const f of ['brand', 'announcement', 'default_sub_url']) if (typeof b[f] === 'string') db[f] = b[f].slice(0, 500);
      if (Array.isArray(b.nodes)) db.nodes = b.nodes.slice(0, 50).map(n => ({ name: String(n.name || '').slice(0, 60), status: n.status === 'offline' ? 'offline' : 'online' }));
      save(); return json(res, 200, {});
    }
    return json(res, 404, { error: 'not found' });
  }

  // ---------- ملفات ثابتة ----------
  let f = url.pathname === '/' ? '/index.html' : url.pathname === '/admin' ? '/admin.html' : url.pathname;
  f = path.normalize(path.join(PUB, f));
  if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream' }); res.end(d);
  });
}).listen(PORT, () => console.log(`Site: http://localhost:${PORT}   Admin: http://localhost:${PORT}/admin`));
